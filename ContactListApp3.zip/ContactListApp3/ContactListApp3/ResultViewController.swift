//
//  ResultViewController.swift
//  ContactListApp3
//
//  Created by Kota,Manoj on 4/21/22.
//

import UIKit

class ResultViewController: UIViewController {

    @IBOutlet weak var EmailOutlet: UILabel!
    
    
    @IBOutlet weak var PhoneNumOutlet: UILabel!
    
    var phoneNum = 0
    var email = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        PhoneNumOutlet.text = "\(phoneNum)"
        EmailOutlet.text = email
        
    }
    

    

}
